package com.greatlearning.tt.mapper;

import com.greatlearning.tt.dto.TicketDto;
import com.greatlearning.tt.entity.Ticket;

public class TicketMapper {


	public static TicketDto mapToTicketDto(Ticket ticket) {


		TicketDto ticketDto = new TicketDto();
		ticketDto.setId(ticket.getId());
		ticketDto.setTitle(ticket.getTitle());
		ticketDto.setUrl(ticket.getUrl());
		ticketDto.setContent(ticket.getContent());
		ticketDto.setShortDescription(ticket.getShortDescription());
		ticketDto.setCreatedOn(ticket.getCreatedOn());
		ticketDto.setUpdatedOn(ticket.getUpdatedOn());


		return ticketDto;

	}

	public static Ticket mapToTicket(TicketDto ticketDto) {
		Ticket ticket = new Ticket();
		ticket.setId(ticketDto.getId());
		ticket.setTitle(ticketDto.getTitle());
		ticket.setUrl(ticketDto.getUrl());
		ticket.setContent(ticketDto.getContent());
		ticket.setShortDescription(ticketDto.getShortDescription());
		ticket.setCreatedOn(ticketDto.getCreatedOn());
		ticket.setUpdatedOn(ticketDto.getUpdatedOn());
		return ticket;
	}
}
