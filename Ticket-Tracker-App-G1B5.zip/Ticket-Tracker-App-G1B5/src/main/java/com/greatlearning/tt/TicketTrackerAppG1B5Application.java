package com.greatlearning.tt;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import com.greatlearning.tt.entity.Ticket;
import com.greatlearning.tt.repository.TicketRepository;

@SpringBootApplication
@EntityScan("com.greatlearning.tt.entity")
public class TicketTrackerAppG1B5Application implements ApplicationRunner {

	public static void main(String[] args) {
		SpringApplication.run(TicketTrackerAppG1B5Application.class, args);
	}

	@Autowired
	private TicketRepository ticketRepository;

	@Override
	public void run(ApplicationArguments args) {
		/*Ticket ticket1 = new Ticket("Sample Ticket",
				"https://example.com/sample-ticket",
				"This is the content of the sample ticket.",
				"Sample ticket description",
				LocalDateTime.of(2023, 10, 8, 10, 0),
				LocalDateTime.of(2023, 10, 8, 15, 30));
		ticketRepository.save(ticket1);
		*/
	}
}