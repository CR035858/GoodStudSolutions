package com.greatlearning.tt.controller;

import java.util.List;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.greatlearning.tt.dto.TicketDto;
import com.greatlearning.tt.service.TicketService;

import jakarta.validation.Valid;


@Controller
public class TicketController {




	private final TicketService ticketService;


	public TicketController(TicketService ticketService) {

		this.ticketService = ticketService;
	}

	@GetMapping("/tickets")
	public String tickets(Model model) {
		List<TicketDto> tickets = ticketService.findAllTickets();
		model.addAttribute("tickets", tickets);
		return "tickets";
	}


	@GetMapping("/tickets/newTicket")
	public String newTicketForm(Model model) {
		TicketDto ticketDto = new TicketDto();
		model.addAttribute("ticket", ticketDto);
		return "create_ticket";
	}
	@PostMapping("/tickets")
	public String createTicket(@Valid @ModelAttribute("ticket") TicketDto ticketDto, BindingResult result) {
		if (result.hasErrors()) {
			return "create_ticket";
		}
		ticketDto.setUrl(getUrl(ticketDto.getTitle()));
		ticketService.createTicket(ticketDto);
		return "redirect:/tickets";
	}


	@GetMapping("/tickets/{ticketId}/edit")
	public String editTicketForm(@PathVariable("ticketId") Long ticketId, Model model) {
		TicketDto ticketDto = ticketService.findTicketById(ticketId);
		model.addAttribute("ticket", ticketDto);
		return "edit_ticket";
	}

	@PostMapping("/tickets/{ticketId}")
	public String updateTicket(@PathVariable("ticketId") Long ticketId,
			@Valid @ModelAttribute("ticket") TicketDto ticketDto, BindingResult result) {
		if (result.hasErrors()) {
			return "edit_ticket";
		}
		ticketDto.setId(ticketId);
		ticketService.updateTicket(ticketDto);
		return "redirect:/tickets";
	}

	@GetMapping("/tickets/{ticketId}/delete")
	public String deleteTicket(@PathVariable("ticketId") Long ticketId) {
		ticketService.deleteTicket(ticketId);
		return "redirect:/tickets";
	}

	@GetMapping("/ticket/{ticketUrl}/view")
	public String viewTicket(@PathVariable("ticketUrl") String ticketUrl, Model model) {
		try {
			TicketDto ticketDto = ticketService.findTicketByUrl(ticketUrl);

			if (ticketDto == null) {
				// Handle the case where the ticket with the given URL doesn't exist
				return "error"; 
			}

			model.addAttribute("ticket", ticketDto);
			return "view_ticket";
		} catch (Exception e) {
			// Handle any exceptions that might occur during ticket retrieval
			e.printStackTrace(); // For debugging purposes, log the exception
			return "error"; 
		}
	}
	@GetMapping("/tickets/search")
	public String searchTickets(@RequestParam(value = "query") String query, Model model) {
		List<TicketDto> tickets = ticketService.searchTickets(query);
		model.addAttribute("tickets", tickets);
		return "tickets";
	}

	private static String getUrl(String ticketTitle) {
		String title = ticketTitle.trim().toLowerCase();
		String url = title.replaceAll("\\s+", "-");
		url = url.replaceAll("[^A-Za-z0-9-]", "");
		return url;
	}
}
