package com.greatlearning.tt.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.greatlearning.tt.entity.Ticket;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

	Optional<Ticket> findByUrl(String url);


	@Query("SELECT p from Ticket p WHERE " +
			" p.title LIKE %:query% OR " +
			" p.shortDescription LIKE %:query%")
	List<Ticket> searchTickets(@Param("query") String query);
}
