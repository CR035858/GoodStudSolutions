package com.greatlearning.tt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketTrackerAppG1B5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
