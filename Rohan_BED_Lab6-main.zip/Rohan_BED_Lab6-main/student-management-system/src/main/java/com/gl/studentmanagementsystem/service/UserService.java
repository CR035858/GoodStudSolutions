package com.gl.studentmanagementsystem.service;

import com.gl.studentmanagementsystem.dto.UserDto;

public interface UserService {

    UserDto save(UserDto userDto);
}
