package com.Orders.SpringRestfulAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestfulApi2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestfulApi2Application.class, args);
		System.out.println("Welcome to Live Session");
	}
}
