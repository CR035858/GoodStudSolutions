package com.GreatLearning.EmployeeManagementRestAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
