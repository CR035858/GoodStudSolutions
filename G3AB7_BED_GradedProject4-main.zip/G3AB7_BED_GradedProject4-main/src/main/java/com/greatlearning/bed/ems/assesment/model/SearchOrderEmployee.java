package com.greatlearning.bed.ems.assesment.model;

public class SearchOrderEmployee {
	private String searchByorder;

	public String getSearchByorder() {
		return searchByorder;
	}

	public void setSearchByorder(String searchByorder) {
		this.searchByorder = searchByorder;
	}

	public SearchOrderEmployee(String searchByorder) {
		super();
		this.searchByorder = searchByorder;
	}
	
	public SearchOrderEmployee() {
		
	}
	
}
