package com.greatlearning.security.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
       /* http.authorizeRequests(requests -> requests
                .antMatchers("/login", "/ h2-console/**", "/swagger-ui.html", "/v2/api-docs", "/swagger-resources/**", "/webjars/**").permitAll()         
        		.antMatchers(HttpMethod.POST, "/tdms/teachers").hasAuthority("ADMIN")
        		.antMatchers(HttpMethod.PUT, "/tdms/teachers").hasAuthority("ADMIN")
        		.antMatchers(HttpMethod.DELETE, "/tdms/teachers/*").hasAuthority("ADMIN")
        		.anyRequest().authenticated().and().httpBasic()
        		.and().cors().and().csrf().disable()
               .headers(headers -> headers.frameOptions().disable());*/
        // /organicVeggies
         http.authorizeRequests()
         	.antMatchers("/login", "/ h2-console/**", "/swagger-ui.html", "/v2/api-docs", "/swagger-resources/**", "/webjars/**").permitAll()         
			.antMatchers(HttpMethod.POST, "/organicVeggies").hasAuthority("ADMIN")
			.antMatchers(HttpMethod.PUT, "/organicVeggies").hasAuthority("ADMIN")
			.antMatchers(HttpMethod.DELETE, "/organicVeggies").hasAuthority("ADMIN")
			.anyRequest().authenticated().and().httpBasic()
			.and().cors().and().csrf().disable();
         
    }
}